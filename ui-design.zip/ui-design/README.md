//@author Himanshu Singal
// Used the template by "Light Bootstrap Dashboard by Creative Tim"
// Modified it as per our use case.

Step1.
Start a webserver with this directory as the root.
I have used mongoose to run a static server. It is included in the root folder. Just double-click mongoose-free-6.9.exe, it runs a webserver in this directory on port 8080.
Thus make sure you don't have any other service running on the port 8080.

Step2.
Open localhost:8080/index.html in Google Chrome. Preferable resolution is 1920*1080 (the monitor on which I developed it). It will also work on 1366*768 though.
